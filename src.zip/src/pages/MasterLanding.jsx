import { useState } from "react";

export default function MasterLanding() {
  const [industry, setIndustry] = useState("Dental");
  const [missedCalls, setMissedCalls] = useState(20);
  const [customerValue, setCustomerValue] = useState(150);

  const recoveredCustomers = Math.round(missedCalls * 0.35);
  const monthlyRevenue = recoveredCustomers * customerValue;

  const industries = [
    "Dental",
    "Med Spa",
    "Hair Salon",
    "Lash Studio",
    "Physical Therapy",
    "Doctor",
  ];

  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        fontFamily: "Inter, Arial, sans-serif",
        background: "#0b0f19",
        color: "white",
      }}
    >
      {/* HEADER */}
      <header
        style={{
          padding: "24px 8%",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "1px solid rgba(255,255,255,.08)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
          }}
        >
          <div
            style={{
              width: "42px",
              height: "42px",
              borderRadius: "12px",
              background: "#2563eb",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: "bold",
            }}
          >
            MC
          </div>

          <div>
            <div style={{ fontWeight: 700 }}>
              Missed Call Booking AI
            </div>
            <div
              style={{
                fontSize: "12px",
                opacity: 0.7,
              }}
            >
              Recover Lost Revenue Automatically
            </div>
          </div>
        </div>

        <button
          style={{
            background: "#2563eb",
            border: "none",
            color: "white",
            padding: "12px 20px",
            borderRadius: "10px",
            cursor: "pointer",
            fontWeight: 600,
          }}
        >
          Book Demo
        </button>
      </header>

      {/* HERO */}
      <section
        style={{
          padding: "100px 8%",
          textAlign: "center",
        }}
      >
        <h1
          style={{
            fontSize: "56px",
            maxWidth: "1000px",
            margin: "0 auto",
            lineHeight: 1.1,
          }}
        >
          Stop Losing Revenue From Missed Calls
        </h1>

        <p
          style={{
            maxWidth: "800px",
            margin: "30px auto",
            fontSize: "22px",
            opacity: 0.8,
          }}
        >
          Every missed call is a potential customer choosing your competitor.
          Our AI instantly follows up and books appointments automatically.
        </p>

        <div
          style={{
            display: "flex",
            gap: "16px",
            justifyContent: "center",
            flexWrap: "wrap",
            marginTop: "30px",
          }}
        >
          <button
            style={{
              background: "#2563eb",
              color: "white",
              border: "none",
              padding: "16px 28px",
              borderRadius: "12px",
              cursor: "pointer",
              fontWeight: 700,
            }}
          >
            Get Started
          </button>

          <button
            style={{
              background: "transparent",
              color: "white",
              border: "1px solid rgba(255,255,255,.2)",
              padding: "16px 28px",
              borderRadius: "12px",
              cursor: "pointer",
            }}
          >
            Watch Demo
          </button>
        </div>
      </section>

      {/* INDUSTRIES */}
      <section
        style={{
          padding: "20px 8% 80px",
          textAlign: "center",
        }}
      >
        <h2 style={{ fontSize: "36px" }}>
          Choose Your Industry
        </h2>

        <div
          style={{
            marginTop: "30px",
            display: "flex",
            flexWrap: "wrap",
            gap: "12px",
            justifyContent: "center",
          }}
        >
          {industries.map((item) => (
            <button
              key={item}
              onClick={() => setIndustry(item)}
              style={{
                background:
                  industry === item ? "#2563eb" : "#141b2d",
                color: "white",
                border: "none",
                padding: "14px 20px",
                borderRadius: "10px",
                cursor: "pointer",
              }}
            >
              {item}
            </button>
          ))}
        </div>
      </section>

      {/* CALCULATOR */}
      <section
        style={{
          padding: "80px 8%",
        }}
      >
        <div
          style={{
            maxWidth: "900px",
            margin: "0 auto",
            background: "#141b2d",
            borderRadius: "20px",
            padding: "40px",
          }}
        >
          <h2
            style={{
              textAlign: "center",
              fontSize: "40px",
            }}
          >
            Revenue Recovery Calculator
          </h2>

          <div style={{ marginTop: "40px" }}>
            <label>
              Missed Calls Per Month: {missedCalls}
            </label>

            <input
              type="range"
              min="1"
              max="100"
              value={missedCalls}
              onChange={(e) =>
                setMissedCalls(Number(e.target.value))
              }
              style={{ width: "100%" }}
            />
          </div>

          <div style={{ marginTop: "40px" }}>
            <label>
              Average Customer Value: ${customerValue}
            </label>

            <input
              type="range"
              min="50"
              max="1000"
              value={customerValue}
              onChange={(e) =>
                setCustomerValue(Number(e.target.value))
              }
              style={{ width: "100%" }}
            />
          </div>

          <div
            style={{
              marginTop: "40px",
              textAlign: "center",
            }}
          >
            <h3>
              Estimated Monthly Revenue Recovered
            </h3>

            <div
              style={{
                fontSize: "52px",
                color: "#4ade80",
                fontWeight: "bold",
              }}
            >
              ${monthlyRevenue.toLocaleString()}
            </div>
          </div>
        </div>
      </section>

      {/* VALUE PROP */}
      <section
        style={{
          padding: "80px 8%",
          textAlign: "center",
        }}
      >
        <h2 style={{ fontSize: "42px" }}>
          One Recovered Customer Can Pay For The Software
        </h2>

        <p
          style={{
            maxWidth: "850px",
            margin: "25px auto",
            fontSize: "22px",
            opacity: 0.8,
          }}
        >
          If your average customer is worth $80-$200+, recovering just one
          missed booking can cover your monthly subscription.
        </p>
      </section>

      {/* HOW IT WORKS */}
      <section
        style={{
          padding: "80px 8%",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "42px",
            marginBottom: "50px",
          }}
        >
          How It Works
        </h2>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(260px,1fr))",
            gap: "25px",
          }}
        >
          {[
            "Customer calls and misses your business",
            "AI instantly follows up by text",
            "Customer books automatically",
          ].map((step, index) => (
            <div
              key={index}
              style={{
                background: "#141b2d",
                padding: "30px",
                borderRadius: "18px",
              }}
            >
              <h3>Step {index + 1}</h3>
              <p>{step}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section
        style={{
          padding: "100px 8%",
          textAlign: "center",
        }}
      >
        <h2 style={{ fontSize: "44px" }}>
          Simple Pricing
        </h2>

        <div
          style={{
            maxWidth: "500px",
            margin: "40px auto",
            background: "#141b2d",
            padding: "50px",
            borderRadius: "20px",
          }}
        >
          <h3 style={{ fontSize: "36px" }}>
            $97/month
          </h3>

          <p>Unlimited missed call recovery</p>
          <p>AI appointment booking</p>
          <p>Analytics dashboard</p>
          <p>Business support</p>

          <button
            style={{
              marginTop: "20px",
              background: "#2563eb",
              color: "white",
              border: "none",
              padding: "14px 24px",
              borderRadius: "10px",
              cursor: "pointer",
            }}
          >
            Start Free Trial
          </button>
        </div>
      </section>

      {/* FAQ */}
      <section
        style={{
          padding: "80px 8%",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            fontSize: "42px",
          }}
        >
          FAQ
        </h2>

        <div
          style={{
            maxWidth: "900px",
            margin: "50px auto",
          }}
        >
          <h3>Does it work with my phone system?</h3>
          <p>
            Yes. We can integrate with most business phone setups.
          </p>

          <h3>How quickly can I start?</h3>
          <p>
            Most businesses are live within 24 hours.
          </p>

          <h3>Will customers know it's AI?</h3>
          <p>
            Conversations feel natural and professional.
          </p>
        </div>
      </section>

      {/* CONTACT */}
      <section
        style={{
          padding: "100px 8%",
          textAlign: "center",
        }}
      >
        <h2 style={{ fontSize: "42px" }}>
          Ready To Recover Lost Revenue?
        </h2>

        <p
          style={{
            marginTop: "20px",
            fontSize: "20px",
            opacity: 0.8,
          }}
        >
          Book a demo and see how many customers you're missing.
        </p>

        <button
          style={{
            marginTop: "30px",
            background: "#2563eb",
            color: "white",
            border: "none",
            padding: "16px 30px",
            borderRadius: "12px",
            cursor: "pointer",
          }}
        >
          Schedule Demo
        </button>
      </section>

      {/* FOOTER */}
      <footer
        style={{
          borderTop: "1px solid rgba(255,255,255,.08)",
          padding: "40px 8%",
          display: "flex",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <div>
          © 2026 Missed Call Booking AI
        </div>

        <div
          style={{
            display: "flex",
            gap: "20px",
          }}
        >
          <a href="/privacy" style={{ color: "white" }}>
            Privacy Policy
          </a>

          <a href="/terms" style={{ color: "white" }}>
            Terms of Service
          </a>

          <a href="/contact" style={{ color: "white" }}>
            Contact
          </a>
        </div>
      </footer>
    </div>
  );
}