import MasterLanding from "./pages/MasterLanding";

export default function App() {
  return <MasterLanding />;
}